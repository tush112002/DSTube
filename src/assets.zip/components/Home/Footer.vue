<template>
  <footer>
    <p>&copy; 2024 DSTube</p>
  </footer>
</template>

<script setup>
</script>

<style scoped>
footer {
  background-color: #333;
  color: #fff;
  padding: 5px 20px;
  margin-left: -10px;
  text-align: center;
  position: fixed;
  bottom: 0;
  width: 100%;
  z-index: 2;
  font-size: 12px; 
}
</style>
